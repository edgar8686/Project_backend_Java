package ru.geekbrains.mini.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
